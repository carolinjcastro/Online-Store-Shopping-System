/****************************************************************
 *  Carolin Castro, cjc494@rutgers.edu
 *  CS 102 (section 06) - Final Homework
 *  [Defining an interface with methods for shopping and checkout]
 ****************************************************************/ 
public interface ShoppingCart {
	
	// ADDTOCART METHOD
	void addToCart(ProductClass product);
	
	// CHECKOUT METHOD
	void checkout();

}
